/**
 * Car.java
 * [Jelaskan kegunaan class ini]
 * @author [NIM] [Nama]
 */
public class Car {
    private int numberOfWheels;
    private Engine engine;
    private Tyre tyre;

    public Car(int numberOfWheels, Engine engine, Tyre tyre) {
        // Konstruktor
    }
  
    public int getNumberOfWheels() {
        // Kembalikan number of wheels
    }

    public void setEngine(Engine engine) {
        // Mengeset mesin mobil
    }

    public void setTyre(Tyre tyre) {
        // Mengeset ban mobil
    }

    public Engine getEngine() {
        // Kembalikan engine
    }

    public Tyre getTyre() {
        // Kembalikan tyre
    }
    
    public String sound(){
        // Kembalikan sound dari engine
    }

    public Boolean isRacingCar() {
        // Apabila isSlickTyre true maka true
        // else false
    }

    public String printDescription(){
        // Apabila isRacingCar true kembalikan "Mobil balap ini memiliki a roda dengan kapasitas mesin x cc" dengan a numberOfWheels dan x engineCapacity
        // else kembalikan "Mobil ini memiliki a roda dengan kapasitas mesin x cc"
    }
}

