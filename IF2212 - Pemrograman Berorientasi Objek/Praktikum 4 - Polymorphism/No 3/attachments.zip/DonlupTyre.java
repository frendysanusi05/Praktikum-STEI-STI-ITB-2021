public class DonlupTyre implements Tyre {
    private int pressure;
    private int width;
    private Boolean isSlick;

    public DonlupTyre(int pressure, int width, Boolean isSlick) {
        // Konstruktor
    }

    @Override
    public int getTyrePressure() {
        // Mengembalikan pressure
    }

    @Override
    public int getTyreWidth() {
        // Mengembalikan width
    }

    @Override
    public Boolean isSlickTyre() {
        // Mengembalikan isSlick
    }
}
