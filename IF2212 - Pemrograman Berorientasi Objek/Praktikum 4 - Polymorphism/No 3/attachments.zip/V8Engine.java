public class V8Engine implements Engine {
    private int engineCapacity;
    private Boolean isSupercharged;

    public V8Engine(int engineCapacity, Boolean isSupercharged) {
        // Konstruktor
    }

    @Override
    public int getEngineCapacity() {
        // Apabila isSupercharged true, engineCapacity + 250
        // else kembalikan engineCapacity
    }

    @Override
    public String sound() {
        // Kembalikan ngengngeng
    }
}
