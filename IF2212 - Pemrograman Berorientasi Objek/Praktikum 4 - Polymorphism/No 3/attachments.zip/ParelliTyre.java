public class ParelliTyre implements Tyre {
    private int pressure;
    private int width;

    public ParelliTyre(int pressure, int width) {
        // Konstruktor
    }

    @Override
    public int getTyrePressure() {
        // Mengembalikan pressure
    }

    @Override
    public int getTyreWidth() {
        // Mengembalikan width
    }

    @Override
    public Boolean isSlickTyre() {
        // Mengembalikan isSlick
    }
}
