/* @author 18221041 Frendy Sanusi */

public interface GraphCalculator extends Calculator, GraphUpgrade {
	
}
