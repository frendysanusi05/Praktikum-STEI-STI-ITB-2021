/* @author 18221041 Frendy Sanusi */

public interface TrackableVehicle extends Vehicle, Trackable {
    
}
