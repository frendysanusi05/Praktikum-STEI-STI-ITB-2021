/* @author 18221041 Frendy Sanusi */

public interface Trackable {
    public String getPlateNumber();
    public Point getGPSPosition();
}